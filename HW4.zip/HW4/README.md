### Jose-Antonio Rubio
### CS 325-400
### Homework 4 Question 4

# Premise
Activity Selection Last-to-Start Suppose that instead of always selecting the first activity to finish, we instead select the last activity to start that is compatible will all previously selected activities. 

# How to Run
activities.py works using Python 2.7.10
It requires a file named act.txt that is supplied (please see file for formatting)
It will then output the the numbers of activities for each set that should be chosen to have a maximum-size subset
of selected activtities

To run activties.py run the following command in your command line
```
python activties.py
```
