### Jose-Antonio Rubio
### CS 325-400
### Homework 1 Question 3

# MergeSort and InsertSort
Implementation of merge sort and insertion sort to sort an array/vector of integers and report run time implemented in python. Both programs read input from command line as to the size of the array.  An array of the size indicated are filled with randomly generated numbers ranging from 1-10000.  Then the respective sorting algorithm is ran on the array

MergeSort.py will output the size of the array and the run time
InsertSort.py will output the size of the array and the run time

# How to Run
Both programs work using Python 2.7.10
To run mergsort.py run the following command in your command line
```
python mergesort.py <number of size array>
```

To run insertsort.py run the following command in your command line
```
python insertsort.py <number of size array>
```
