### Jose-Antonio Rubio
### CS 325-400
### Homework 2

# MergeSort and InsertSort
Implementation of Stooge sort to sort an array/vector of integers and report run time implemented in python. The program reads input from command line as to the size of the array.  An array of the size indicated are filled with randomly generated numbers ranging from 1-10000.  Then the respective sorting algorithm is ran on the array

stoogeSort.py will output the size of the array and the run time

# How to Run
Program work using Python 2.7.10
To run stoogeSort.py run the following command in your command line
```
python mergesort.py <number of size array>
```